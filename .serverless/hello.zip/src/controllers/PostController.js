"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const PostService_1 = __importDefault(require("../services/PostService"));
const router = (0, express_1.Router)();
const postService = new PostService_1.default();
// GET all posts
router.get('/', async (req, res) => {
    try {
        const posts = await postService.getAllPosts();
        res.json(posts);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
// GET a single post by ID
router.get('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const post = await postService.getPostById(id);
        if (post) {
            res.json(post);
        }
        else {
            res.status(404).json({ message: 'Post não encontrado' });
        }
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
// POST create a new post
router.post('/', async (req, res) => {
    const { title, content } = req.body;
    if (!title || !content) {
        return res.status(400).json({ message: 'Título e conteúdo são obrigatórios' });
    }
    try {
        const post = await postService.createPost(title, content);
        res.status(201).json(post);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
// PUT update the state of a post (e.g., publish)
router.put('/:id/publish', async (req, res) => {
    const { id } = req.params;
    try {
        await postService.updatePostState(id, "published");
        res.json({ message: `Post ${id} publicado com sucesso` });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
// DELETE a post
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await postService.deletePost(id);
        res.json({ message: `Post ${id} deletado com sucesso` });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
});
exports.default = router;
