"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ddbDocClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Configuração do cliente DynamoDB
const REGION = process.env.AWS_REGION || "us-east-1"; // Região padrão
const ddbClient = new client_dynamodb_1.DynamoDBClient({ region: REGION });
const ddbDocClient = lib_dynamodb_1.DynamoDBDocumentClient.from(ddbClient);
exports.ddbDocClient = ddbDocClient;
