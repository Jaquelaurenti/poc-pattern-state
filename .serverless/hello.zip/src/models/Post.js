"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DraftState_1 = require("../states/DraftState");
const PublishedState_1 = require("../states/PublishedState");
const uuid_1 = require("uuid");
class Post {
    constructor(title, content) {
        this.id = (0, uuid_1.v4)();
        this.title = title;
        this.content = content;
        this.draftState = new DraftState_1.DraftState(this);
        this.publishedState = new PublishedState_1.PublishedState(this);
        this.state = this.draftState; // Estado inicial
        const now = new Date().toISOString();
        this.createdAt = now;
        this.updatedAt = now;
    }
    setState(state) {
        this.state = state;
    }
    publish() {
        this.state.publish();
        this.updatedAt = new Date().toISOString();
    }
    delete() {
        this.state.delete();
        this.updatedAt = new Date().toISOString();
    }
}
exports.default = Post;
