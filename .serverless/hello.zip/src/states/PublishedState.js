"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishedState = void 0;
const PostState_1 = require("./PostState");
class PublishedState extends PostState_1.PostState {
    delete() {
        console.log('Deletando post publicado...');
        this.post.setState(this.post.draftState);
    }
}
exports.PublishedState = PublishedState;
