"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostState = void 0;
class PostState {
    constructor(post) {
        this.post = post;
    }
    publish() {
        console.log('Mudança de estado não permitida.');
    }
    delete() {
        console.log('Mudança de estado não permitida.');
    }
}
exports.PostState = PostState;
