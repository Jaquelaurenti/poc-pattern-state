"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DraftState = void 0;
const PostState_1 = require("./PostState");
class DraftState extends PostState_1.PostState {
    publish() {
        console.log('Publicando post...');
        this.post.setState(this.post.publishedState);
    }
}
exports.DraftState = DraftState;
